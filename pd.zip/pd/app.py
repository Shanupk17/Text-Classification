from flask import Flask, request, render_template
from keras.models import Sequential, load_model
from keras.layers import SimpleRNN, Dense, Embedding
from keras.preprocessing.text import Tokenizer
from keras.preprocessing.sequence import pad_sequences
import numpy as np
import pickle
import os
import re

app = Flask(__name__)

# Utility function for preprocessing text
def preprocess_text(text):
    text = text.lower()
    text = re.sub(r'\s+', ' ', text)
    return text

# Utility function to save the model and tokenizer
def save_model_and_tokenizer(rnn_model, tokenizer):
    rnn_model.save('rnn_model.h5')
    with open('tokenizer.pkl', 'wb') as f:
        pickle.dump(tokenizer, f)

# Train models based on the input paragraph
def train_model(texts, labels):
    tokenizer = Tokenizer(num_words=10000)
    tokenizer.fit_on_texts(texts)
    sequences = tokenizer.texts_to_sequences(texts)
    X = pad_sequences(sequences, maxlen=100)
    y = np.array(labels)

    # Define and train Simple RNN model
    rnn_model = Sequential()
    rnn_model.add(Embedding(input_dim=10000, output_dim=128, input_length=100))
    rnn_model.add(SimpleRNN(128, return_sequences=True))
    rnn_model.add(SimpleRNN(64))
    rnn_model.add(Dense(1, activation='sigmoid'))
    rnn_model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])
    rnn_model.fit(X, y, epochs=1, batch_size=1)  # Use batch_size=1 for simplicity

    save_model_and_tokenizer(rnn_model, tokenizer)

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/analyze', methods=['POST'])
def analyze():
    paragraph = request.form['paragraph']
    word = request.form['word']
    
    processed_paragraph = preprocess_text(paragraph)
    
    # Prepare data for training
    texts = [processed_paragraph]
    labels = [0]  # Dummy label for simplicity; you might need actual labels based on context
    
    # Train model and save it
    train_model(texts, labels)
    
    # Load model
    rnn_model = load_model('rnn_model.h5')

    # Load tokenizer
    with open('tokenizer.pkl', 'rb') as f:
        tokenizer = pickle.load(f)

    # Prepare input for prediction
    sequences = tokenizer.texts_to_sequences([processed_paragraph])
    X = pad_sequences(sequences, maxlen=100)
    
    # Predict with model
    rnn_prediction = rnn_model.predict(X)

    # Compute word frequency
    words = processed_paragraph.split()
    word_count = words.count(word.lower())
    
    # Check if the word is unique
    is_unique = word_count == 1

    result = {
        'frequency': word_count,
        'is_unique': is_unique,
        'rnn_prediction': rnn_prediction[0][0]  # Adjust based on your model's output
    }
    
    return render_template('index.html', result=result)

if __name__ == '__main__':
    if not os.path.isfile('rnn_model.h5'):
        print("No pre-trained model found. Please train the model first.")
    app.run(debug=True)
